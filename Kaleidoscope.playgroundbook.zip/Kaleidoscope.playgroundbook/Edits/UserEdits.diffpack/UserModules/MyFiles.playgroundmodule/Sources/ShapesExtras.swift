import CoreGraphics
import UIKit
import SpriteKit

public extension Graphic {
    /// Creates a slight pulsing animation on a graphic.
    func pulse() {
        let currentScale = self.scale
        let scaleUp = SKAction.scale(by: 1.15, duration: 0.15)
        let scaleBack = SKAction.scale(to: CGFloat(currentScale), duration: 0.075)
        let sequence = SKAction.sequence([scaleUp, scaleBack])
        self.run(sequence)
    }
}
